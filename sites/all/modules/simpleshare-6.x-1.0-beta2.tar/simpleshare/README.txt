
Simple Share
------------

Simple sharing of URLs using various methods. Supports Twitter, Facebook and
email.

Install instructions
--------------------

- Install drupal module.
- Go to admin/settings/simpleshare and pick which share methods should be
  available.
- Enable Simple Share on nodes by enabling it via content type edit forms.
- Alterntively, use Views module to add a share link to your listing 
  ("Simple Share link" field)

